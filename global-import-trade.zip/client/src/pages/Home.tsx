/*
 * DESIGN: Luxury Trading House - Main Page
 * Sections: Hero, Stats, About, Products, Countries, Dealers, Contact
 * Color: Deep Navy (#1A2744) + Antique Gold (#C9A84C) + Ivory (#F8F6F1)
 * Fonts: Playfair Display (headings) + Noto Sans KR (body)
 */
import { useEffect, useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ChevronDown, Star, Award, Truck, Globe, Phone, Mail, MapPin, CheckCircle, ArrowRight } from "lucide-react";

// Image CDN URLs
const IMAGES = {
  hero: "https://d2xsxph8kpxj0f.cloudfront.net/310519663566540860/6mxAS2DEGiETgNFAgCueuF/hero-banner-gbnfT6fdKdxRzMRCdhJKnZ.webp",
  christmas: "https://d2xsxph8kpxj0f.cloudfront.net/310519663566540860/6mxAS2DEGiETgNFAgCueuF/christmas-products-A7cGuMwDafJ3kwUuPvjE5r.webp",
  flowers: "https://d2xsxph8kpxj0f.cloudfront.net/310519663566540860/6mxAS2DEGiETgNFAgCueuF/artificial-flowers-mRcahPJAe7RfqTkejpSoij.webp",
  interior: "https://d2xsxph8kpxj0f.cloudfront.net/310519663566540860/6mxAS2DEGiETgNFAgCueuF/interior-decor-XNqhALKdc5jEZhfCwB3w52.webp",
  globalTrade: "https://d2xsxph8kpxj0f.cloudfront.net/310519663566540860/6mxAS2DEGiETgNFAgCueuF/global-trade-o54waibrHuu9kiknd3f5CT.webp",
};

// Animated counter hook
function useCounter(target: number, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);
  return count;
}

// Intersection observer hook
function useInView(threshold = 0.2) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, inView };
}

// Section wrapper with fade-in
function Section({ id, children, className = "", style }: { id?: string; children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  const { ref, inView } = useInView();
  return (
    <section
      id={id}
      ref={ref}
      className={`transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} ${className}`}
      style={style}
    >
      {children}
    </section>
  );
}

// Section heading component
function SectionHeading({ subtitle, title, description, light = false }: {
  subtitle: string; title: string; description?: string; light?: boolean;
}) {
  return (
    <div className="text-center mb-14">
      <div
        className="inline-block text-xs font-semibold uppercase tracking-[0.25em] mb-3 px-4 py-1.5 rounded-sm"
        style={{
          color: light ? "oklch(0.72 0.12 75)" : "oklch(0.22 0.065 255)",
          backgroundColor: light ? "oklch(0.72 0.12 75 / 0.15)" : "oklch(0.22 0.065 255 / 0.08)",
          fontFamily: "'Cormorant Garamond', serif",
        }}
      >
        {subtitle}
      </div>
      <h2
        className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
        style={{
          fontFamily: "'Playfair Display', serif",
          color: light ? "oklch(0.975 0.008 85)" : "oklch(0.15 0.01 65)",
        }}
      >
        {title}
      </h2>
      {description && (
        <p
          className="max-w-2xl mx-auto text-base leading-relaxed"
          style={{ color: light ? "oklch(0.75 0.01 85)" : "oklch(0.5 0.01 65)" }}
        >
          {description}
        </p>
      )}
      <div className="gold-divider w-24 mx-auto mt-6" />
    </div>
  );
}

export default function Home() {
  const [statsVisible, setStatsVisible] = useState(false);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStatsVisible(true); },
      { threshold: 0.3 }
    );
    if (statsRef.current) observer.observe(statsRef.current);
    return () => observer.disconnect();
  }, []);

  const years = useCounter(15, 1800, statsVisible);
  const products = useCounter(3000, 2000, statsVisible);
  const dealers = useCounter(500, 1800, statsVisible);
  const countries = useCounter(4, 1200, statsVisible);

  return (
    <div className="min-h-screen" style={{ backgroundColor: "oklch(0.975 0.008 85)" }}>
      <Navbar />

      {/* ===== HERO SECTION ===== */}
      <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${IMAGES.hero})` }}
        />
        {/* Overlay */}
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(135deg, oklch(0.15 0.055 255 / 0.88) 0%, oklch(0.22 0.065 255 / 0.75) 50%, oklch(0.15 0.055 255 / 0.6) 100%)" }}
        />

        <div className="container relative z-10 pt-20">
          <div className="max-w-3xl">
            {/* Badge */}
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-sm mb-8 text-xs font-semibold uppercase tracking-widest"
              style={{
                backgroundColor: "oklch(0.72 0.12 75 / 0.2)",
                border: "1px solid oklch(0.72 0.12 75 / 0.5)",
                color: "oklch(0.85 0.09 75)",
                fontFamily: "'Cormorant Garamond', serif",
              }}
            >
              <Globe className="w-3.5 h-3.5" />
              해외 수입 & 디자인 개발 전문
            </div>

            {/* Main Title */}
            <h1
              className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "oklch(0.975 0.008 85)",
              }}
            >
              세계의 아름다움을
              <br />
              <span style={{ color: "oklch(0.85 0.09 75)" }}>당신의 공간으로</span>
            </h1>

            {/* Subtitle */}
            <p
              className="text-lg md:text-xl leading-relaxed mb-10 max-w-xl"
              style={{ color: "oklch(0.85 0.01 85)", fontFamily: "'Noto Sans KR', sans-serif" }}
            >
              중국, 독일, 인도, 일본에서 엄선된 크리스마스 용품, 조화, 인테리어 소품을 수입하여
              전국 도매 납품합니다.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => document.querySelector("#products")?.scrollIntoView({ behavior: "smooth" })}
                className="flex items-center gap-2 px-8 py-4 font-semibold text-sm rounded-sm transition-all duration-200 hover:scale-105 hover:shadow-lg"
                style={{
                  backgroundColor: "oklch(0.72 0.12 75)",
                  color: "oklch(0.15 0.01 65)",
                  fontFamily: "'Noto Sans KR', sans-serif",
                }}
              >
                제품 보기
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
                className="flex items-center gap-2 px-8 py-4 font-semibold text-sm rounded-sm transition-all duration-200 hover:bg-white/20"
                style={{
                  border: "1px solid oklch(0.975 0.008 85 / 0.5)",
                  color: "oklch(0.975 0.008 85)",
                  fontFamily: "'Noto Sans KR', sans-serif",
                }}
              >
                거래 문의
              </button>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <span className="text-xs uppercase tracking-widest" style={{ color: "oklch(0.72 0.12 75)" }}>Scroll</span>
          <ChevronDown className="w-5 h-5" style={{ color: "oklch(0.72 0.12 75)" }} />
        </div>
      </section>

      {/* ===== STATS SECTION ===== */}
      <div
        ref={statsRef}
        style={{ backgroundColor: "oklch(0.22 0.065 255)" }}
        className="py-12"
      >
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: years, suffix: "년+", label: "업력" },
              { value: products, suffix: "종+", label: "취급 제품" },
              { value: dealers, suffix: "개+", label: "전국 판매처" },
              { value: countries, suffix: "개국", label: "수입 국가" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div
                  className="text-4xl md:text-5xl font-bold mb-1"
                  style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.85 0.09 75)" }}
                >
                  {stat.value}{stat.suffix}
                </div>
                <div
                  className="text-sm font-medium uppercase tracking-widest"
                  style={{ color: "oklch(0.7 0.01 85)" }}
                >
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ===== ABOUT SECTION ===== */}
      <Section id="about" className="py-24">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Image */}
            <div className="relative">
              <div
                className="absolute -top-4 -left-4 w-full h-full rounded-sm"
                style={{ backgroundColor: "oklch(0.72 0.12 75 / 0.15)", border: "1px solid oklch(0.72 0.12 75 / 0.3)" }}
              />
              <img
                src={IMAGES.globalTrade}
                alt="글로벌 수입 무역"
                className="relative z-10 w-full rounded-sm object-cover"
                style={{ height: "420px" }}
              />
              {/* Badge overlay */}
              <div
                className="absolute -bottom-6 -right-6 z-20 p-5 rounded-sm shadow-xl"
                style={{ backgroundColor: "oklch(0.22 0.065 255)" }}
              >
                <div className="text-center">
                  <div className="text-3xl font-bold" style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.85 0.09 75)" }}>15+</div>
                  <div className="text-xs uppercase tracking-widest mt-1" style={{ color: "oklch(0.7 0.01 85)" }}>Years of Excellence</div>
                </div>
              </div>
            </div>

            {/* Content */}
            <div>
              <div
                className="text-xs font-semibold uppercase tracking-[0.25em] mb-4"
                style={{ color: "oklch(0.72 0.12 75)", fontFamily: "'Cormorant Garamond', serif" }}
              >
                About Us
              </div>
              <h2
                className="text-3xl md:text-4xl font-bold mb-6"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.15 0.01 65)" }}
              >
                해외 수입 & 디자인 개발의
                <br />
                <span style={{ color: "oklch(0.22 0.065 255)" }}>전문 파트너</span>
              </h2>
              <div className="gold-divider w-16 mb-8" style={{ marginLeft: 0 }} />
              <p className="text-base leading-relaxed mb-6" style={{ color: "oklch(0.45 0.01 65)" }}>
                저희 글로벌 수입 무역은 15년 이상의 경험을 바탕으로 중국, 독일, 인도, 일본 등 세계 각지에서
                트렌디하고 품질 높은 제품을 직접 발굴하고 수입합니다. 크리스마스 용품, 조화, 인테리어 소품 등
                다양한 카테고리의 제품을 전국 도매 업체에 납품하고 있습니다.
              </p>
              <p className="text-base leading-relaxed mb-8" style={{ color: "oklch(0.45 0.01 65)" }}>
                단순한 수입 대행을 넘어 자체 디자인 개발을 통해 차별화된 제품을 선보이며,
                고객사의 니즈에 맞는 맞춤형 소싱 서비스도 제공합니다.
              </p>

              {/* Features */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  "자체 디자인 개발",
                  "직접 수입으로 가격 경쟁력",
                  "전국 도매 납품 네트워크",
                  "신속한 재고 관리",
                  "다양한 제품 카테고리",
                  "맞춤형 소싱 서비스",
                ].map((feature) => (
                  <div key={feature} className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 shrink-0" style={{ color: "oklch(0.72 0.12 75)" }} />
                    <span className="text-sm" style={{ color: "oklch(0.35 0.01 65)" }}>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* ===== PRODUCTS SECTION ===== */}
      <Section id="products" className="py-24" style={{ backgroundColor: "oklch(0.97 0.005 85)" }}>
        <div className="container">
          <SectionHeading
            subtitle="Our Products"
            title="주요 제품 카테고리"
            description="세계 각지에서 엄선된 프리미엄 제품들을 소개합니다. 크리스마스 용품부터 인테리어 소품까지 다양한 카테고리를 취급합니다."
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                image: IMAGES.christmas,
                category: "Christmas Collection",
                title: "크리스마스 용품",
                description: "독일과 중국에서 수입한 고품질 크리스마스 장식품. 오너먼트, 리스, 트리 장식, 스노우글로브 등 다양한 제품을 취급합니다.",
                tags: ["오너먼트", "리스", "트리 장식", "스노우글로브"],
                origin: "🇩🇪 독일 · 🇨🇳 중국",
              },
              {
                image: IMAGES.flowers,
                category: "Artificial Flowers",
                title: "조화 (인공 꽃)",
                description: "중국과 인도에서 수입한 고품질 실크 조화. 장미, 유칼립투스, 팜파스 그라스 등 다양한 종류의 인공 꽃을 제공합니다.",
                tags: ["실크 장미", "유칼립투스", "팜파스", "혼합 부케"],
                origin: "🇨🇳 중국 · 🇮🇳 인도",
              },
              {
                image: IMAGES.interior,
                category: "Interior Decor",
                title: "인테리어 소품",
                description: "독일, 일본, 인도에서 수입한 세련된 인테리어 소품. 화병, 캔들 홀더, 장식 조각품, 액자 등 홈 데코 아이템을 취급합니다.",
                tags: ["화병", "캔들 홀더", "장식 조각", "액자"],
                origin: "🇩🇪 독일 · 🇯🇵 일본 · 🇮🇳 인도",
              },
            ].map((product) => (
              <div key={product.title} className="luxury-card rounded-sm overflow-hidden group">
                {/* Image */}
                <div className="relative overflow-hidden" style={{ height: "260px" }}>
                  <img
                    src={product.image}
                    alt={product.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div
                    className="absolute top-4 left-4 px-3 py-1 rounded-sm text-xs font-semibold uppercase tracking-wider"
                    style={{
                      backgroundColor: "oklch(0.22 0.065 255)",
                      color: "oklch(0.85 0.09 75)",
                      fontFamily: "'Cormorant Garamond', serif",
                    }}
                  >
                    {product.category}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="text-xs mb-2" style={{ color: "oklch(0.72 0.12 75)" }}>{product.origin}</div>
                  <h3
                    className="text-xl font-bold mb-3"
                    style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.15 0.01 65)" }}
                  >
                    {product.title}
                  </h3>
                  <p className="text-sm leading-relaxed mb-4" style={{ color: "oklch(0.5 0.01 65)" }}>
                    {product.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {product.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs px-2 py-1 rounded-sm"
                        style={{
                          backgroundColor: "oklch(0.22 0.065 255 / 0.08)",
                          color: "oklch(0.22 0.065 255)",
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Additional categories */}
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: "🎁", title: "선물 포장 용품", desc: "리본, 포장지, 선물 박스" },
              { icon: "🕯️", title: "캔들 & 향초", desc: "아로마 캔들, 홀더" },
              { icon: "🌿", title: "계절 장식품", desc: "봄·여름·가을·겨울" },
              { icon: "🏮", title: "조명 장식", desc: "LED 조명, 랜턴" },
            ].map((item) => (
              <div
                key={item.title}
                className="p-5 rounded-sm text-center luxury-card"
              >
                <div className="text-3xl mb-3">{item.icon}</div>
                <h4 className="text-sm font-bold mb-1" style={{ color: "oklch(0.22 0.065 255)" }}>{item.title}</h4>
                <p className="text-xs" style={{ color: "oklch(0.55 0.01 65)" }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ===== COUNTRIES SECTION ===== */}
      <Section
        id="countries"
        className="py-24"
        style={{ backgroundColor: "oklch(0.22 0.065 255)" }}
      >
        <div className="container">
          <SectionHeading
            subtitle="Import Countries"
            title="수입 국가"
            description="세계 4개국의 우수한 제조사와 직접 파트너십을 맺고 최고 품질의 제품을 수입합니다."
            light
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                flag: "🇨🇳",
                country: "중국",
                english: "China",
                products: ["크리스마스 오너먼트", "조화 & 실크 플라워", "LED 조명 장식", "선물 포장 용품"],
                highlight: "최대 수입국",
                color: "oklch(0.72 0.12 75)",
              },
              {
                flag: "🇩🇪",
                country: "독일",
                english: "Germany",
                products: ["프리미엄 크리스마스 장식", "유럽풍 인테리어 소품", "고급 캔들 홀더", "장식용 조각품"],
                highlight: "유럽 프리미엄",
                color: "oklch(0.65 0.15 30)",
              },
              {
                flag: "🇮🇳",
                country: "인도",
                english: "India",
                products: ["수공예 인테리어 소품", "황동 & 금속 장식품", "천연 소재 조화", "전통 문양 장식"],
                highlight: "수공예 전문",
                color: "oklch(0.72 0.18 55)",
              },
              {
                flag: "🇯🇵",
                country: "일본",
                english: "Japan",
                products: ["미니멀 인테리어 소품", "고품질 도자기", "계절 장식품", "정밀 공예품"],
                highlight: "정밀 품질",
                color: "oklch(0.65 0.12 10)",
              },
            ].map((country) => (
              <div
                key={country.country}
                className="rounded-sm p-6 transition-all duration-300 hover:-translate-y-2"
                style={{
                  backgroundColor: "oklch(0.28 0.065 255)",
                  border: "1px solid oklch(0.35 0.065 255)",
                }}
              >
                <div className="text-5xl mb-4">{country.flag}</div>
                <div
                  className="inline-block text-xs px-2 py-0.5 rounded-sm mb-3 font-semibold"
                  style={{ backgroundColor: `${country.color} / 0.2`, color: country.color }}
                >
                  {country.highlight}
                </div>
                <h3
                  className="text-2xl font-bold mb-1"
                  style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.975 0.008 85)" }}
                >
                  {country.country}
                </h3>
                <p
                  className="text-xs uppercase tracking-widest mb-5"
                  style={{ color: "oklch(0.6 0.01 85)", fontFamily: "'Cormorant Garamond', serif" }}
                >
                  {country.english}
                </p>
                <ul className="space-y-2">
                  {country.products.map((product) => (
                    <li key={product} className="flex items-center gap-2 text-sm" style={{ color: "oklch(0.8 0.01 85)" }}>
                      <span style={{ color: "oklch(0.72 0.12 75)" }}>•</span>
                      {product}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ===== WHY US SECTION ===== */}
      <Section className="py-24">
        <div className="container">
          <SectionHeading
            subtitle="Why Choose Us"
            title="왜 글로벌 수입 무역인가"
            description="15년간 쌓아온 신뢰와 전문성으로 최고의 파트너가 되겠습니다."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <Globe className="w-8 h-8" />,
                title: "직접 수입",
                description: "중간 유통 없이 해외 제조사에서 직접 수입하여 최상의 가격 경쟁력을 제공합니다.",
              },
              {
                icon: <Award className="w-8 h-8" />,
                title: "품질 보증",
                description: "엄격한 품질 검수 과정을 통해 검증된 제품만을 납품합니다.",
              },
              {
                icon: <Truck className="w-8 h-8" />,
                title: "전국 납품",
                description: "전국 어디서나 신속하고 안전하게 제품을 납품하는 물류 네트워크를 보유합니다.",
              },
              {
                icon: <Star className="w-8 h-8" />,
                title: "디자인 개발",
                description: "자체 디자인 팀을 통해 트렌드를 반영한 신제품을 지속적으로 개발합니다.",
              },
            ].map((item) => (
              <div key={item.title} className="luxury-card p-8 rounded-sm text-center group">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-5 transition-all duration-300 group-hover:scale-110"
                  style={{ backgroundColor: "oklch(0.22 0.065 255 / 0.08)", color: "oklch(0.22 0.065 255)" }}
                >
                  {item.icon}
                </div>
                <h3
                  className="text-lg font-bold mb-3"
                  style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.15 0.01 65)" }}
                >
                  {item.title}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "oklch(0.5 0.01 65)" }}>
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ===== DEALERS SECTION ===== */}
      <Section
        id="dealers"
        className="py-24"
        style={{ backgroundColor: "oklch(0.97 0.005 85)" }}
      >
        <div className="container">
          <SectionHeading
            subtitle="Nationwide Dealers"
            title="전국 판매처 안내"
            description="전국 주요 도시의 판매처에서 저희 제품을 만나보실 수 있습니다."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {[
              {
                region: "수도권",
                cities: ["서울 동대문 도매시장", "서울 남대문 시장", "인천 종합도매시장", "경기 수원 도매센터"],
                count: "150+",
              },
              {
                region: "충청권",
                cities: ["대전 중앙도매시장", "청주 도매유통센터", "천안 도매상가", "세종 유통단지"],
                count: "80+",
              },
              {
                region: "영남권",
                cities: ["부산 국제시장", "대구 서문시장", "울산 도매센터", "경남 창원 유통단지"],
                count: "120+",
              },
              {
                region: "호남권",
                cities: ["광주 양동시장", "전주 도매시장", "목포 유통센터", "여수 도매상가"],
                count: "70+",
              },
              {
                region: "강원권",
                cities: ["춘천 도매시장", "원주 유통단지", "강릉 도매센터"],
                count: "40+",
              },
              {
                region: "제주권",
                cities: ["제주시 도매시장", "서귀포 유통센터"],
                count: "20+",
              },
            ].map((dealer) => (
              <div key={dealer.region} className="luxury-card p-6 rounded-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3
                    className="text-lg font-bold"
                    style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.22 0.065 255)" }}
                  >
                    {dealer.region}
                  </h3>
                  <span
                    className="text-sm font-bold px-3 py-1 rounded-sm"
                    style={{ backgroundColor: "oklch(0.72 0.12 75 / 0.15)", color: "oklch(0.55 0.1 75)" }}
                  >
                    {dealer.count} 판매처
                  </span>
                </div>
                <div className="gold-divider mb-4" />
                <ul className="space-y-2">
                  {dealer.cities.map((city) => (
                    <li key={city} className="flex items-center gap-2 text-sm" style={{ color: "oklch(0.45 0.01 65)" }}>
                      <MapPin className="w-3.5 h-3.5 shrink-0" style={{ color: "oklch(0.72 0.12 75)" }} />
                      {city}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* CTA Banner */}
          <div
            className="rounded-sm p-8 md:p-12 text-center"
            style={{ backgroundColor: "oklch(0.22 0.065 255)" }}
          >
            <h3
              className="text-2xl md:text-3xl font-bold mb-4"
              style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.975 0.008 85)" }}
            >
              판매처 등록을 원하시나요?
            </h3>
            <p className="text-base mb-8" style={{ color: "oklch(0.75 0.01 85)" }}>
              전국 도매 판매처 네트워크에 참여하여 경쟁력 있는 가격으로 제품을 공급받으세요.
            </p>
            <button
              onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
              className="px-8 py-4 font-semibold text-sm rounded-sm transition-all duration-200 hover:scale-105"
              style={{
                backgroundColor: "oklch(0.72 0.12 75)",
                color: "oklch(0.15 0.01 65)",
                fontFamily: "'Noto Sans KR', sans-serif",
              }}
            >
              판매처 등록 문의
            </button>
          </div>
        </div>
      </Section>

      {/* ===== CONTACT SECTION ===== */}
      <Section id="contact" className="py-24">
        <div className="container">
          <SectionHeading
            subtitle="Contact Us"
            title="문의하기"
            description="거래 문의, 제품 상담, 판매처 등록 등 궁금하신 사항을 문의해 주세요."
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h3
                className="text-xl font-bold mb-8"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.15 0.01 65)" }}
              >
                연락처 정보
              </h3>

              <div className="space-y-6 mb-10">
                {[
                  {
                    icon: <Phone className="w-5 h-5" />,
                    title: "전화 문의",
                    content: "02-000-0000",
                    sub: "평일 09:00 - 18:00 (점심 12:00 - 13:00)",
                  },
                  {
                    icon: <Mail className="w-5 h-5" />,
                    title: "이메일 문의",
                    content: "info@globalimport.co.kr",
                    sub: "24시간 접수, 영업일 기준 1일 내 답변",
                  },
                  {
                    icon: <MapPin className="w-5 h-5" />,
                    title: "사무실 주소",
                    content: "서울특별시 중구 을지로",
                    sub: "방문 전 사전 예약 필수",
                  },
                ].map((info) => (
                  <div key={info.title} className="flex items-start gap-4">
                    <div
                      className="w-12 h-12 rounded-sm flex items-center justify-center shrink-0"
                      style={{ backgroundColor: "oklch(0.22 0.065 255 / 0.08)", color: "oklch(0.22 0.065 255)" }}
                    >
                      {info.icon}
                    </div>
                    <div>
                      <div className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: "oklch(0.72 0.12 75)" }}>
                        {info.title}
                      </div>
                      <div className="text-base font-medium" style={{ color: "oklch(0.15 0.01 65)" }}>{info.content}</div>
                      <div className="text-sm" style={{ color: "oklch(0.55 0.01 65)" }}>{info.sub}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Business Hours */}
              <div
                className="p-6 rounded-sm"
                style={{ backgroundColor: "oklch(0.97 0.005 85)", border: "1px solid oklch(0.88 0.01 85)" }}
              >
                <h4 className="text-sm font-bold mb-4" style={{ color: "oklch(0.22 0.065 255)" }}>영업 시간</h4>
                <div className="space-y-2">
                  {[
                    { day: "월요일 - 금요일", time: "09:00 - 18:00" },
                    { day: "토요일", time: "09:00 - 13:00" },
                    { day: "일요일 · 공휴일", time: "휴무" },
                  ].map((schedule) => (
                    <div key={schedule.day} className="flex justify-between text-sm">
                      <span style={{ color: "oklch(0.45 0.01 65)" }}>{schedule.day}</span>
                      <span className="font-medium" style={{ color: "oklch(0.22 0.065 255)" }}>{schedule.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div
              className="p-8 rounded-sm shadow-lg"
              style={{ backgroundColor: "white", border: "1px solid oklch(0.88 0.01 85)" }}
            >
              <h3
                className="text-xl font-bold mb-6"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.15 0.01 65)" }}
              >
                문의 양식
              </h3>
              <ContactForm />
            </div>
          </div>
        </div>
      </Section>

      <Footer />
    </div>
  );
}

function ContactForm() {
  const [form, setForm] = useState({
    name: "",
    company: "",
    phone: "",
    email: "",
    type: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
    setForm({ name: "", company: "", phone: "", email: "", type: "", message: "" });
  };

  const inputStyle = {
    width: "100%",
    padding: "10px 14px",
    borderRadius: "4px",
    border: "1px solid oklch(0.88 0.01 85)",
    fontSize: "14px",
    color: "oklch(0.15 0.01 65)",
    backgroundColor: "oklch(0.975 0.008 85)",
    outline: "none",
    fontFamily: "'Noto Sans KR', sans-serif",
    transition: "border-color 0.2s",
  };

  const labelStyle = {
    display: "block",
    fontSize: "12px",
    fontWeight: "600",
    marginBottom: "6px",
    color: "oklch(0.35 0.01 65)",
    textTransform: "uppercase" as const,
    letterSpacing: "0.05em",
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <CheckCircle className="w-16 h-16 mb-4" style={{ color: "oklch(0.55 0.15 145)" }} />
        <h4 className="text-lg font-bold mb-2" style={{ color: "oklch(0.22 0.065 255)" }}>문의가 접수되었습니다!</h4>
        <p className="text-sm" style={{ color: "oklch(0.5 0.01 65)" }}>영업일 기준 1일 내에 답변 드리겠습니다.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label style={labelStyle}>담당자명 *</label>
          <input
            type="text"
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="홍길동"
            style={inputStyle}
          />
        </div>
        <div>
          <label style={labelStyle}>회사명</label>
          <input
            type="text"
            value={form.company}
            onChange={(e) => setForm({ ...form, company: e.target.value })}
            placeholder="(주)회사명"
            style={inputStyle}
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label style={labelStyle}>연락처 *</label>
          <input
            type="tel"
            required
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="010-0000-0000"
            style={inputStyle}
          />
        </div>
        <div>
          <label style={labelStyle}>이메일</label>
          <input
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="email@company.com"
            style={inputStyle}
          />
        </div>
      </div>
      <div>
        <label style={labelStyle}>문의 유형 *</label>
        <select
          required
          value={form.type}
          onChange={(e) => setForm({ ...form, type: e.target.value })}
          style={inputStyle}
        >
          <option value="">선택해 주세요</option>
          <option value="wholesale">도매 거래 문의</option>
          <option value="dealer">판매처 등록 문의</option>
          <option value="product">제품 상담</option>
          <option value="custom">맞춤 소싱 문의</option>
          <option value="other">기타 문의</option>
        </select>
      </div>
      <div>
        <label style={labelStyle}>문의 내용 *</label>
        <textarea
          required
          rows={4}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          placeholder="문의하실 내용을 자세히 적어주세요..."
          style={{ ...inputStyle, resize: "vertical" }}
        />
      </div>
      <button
        type="submit"
        className="w-full py-3.5 font-semibold text-sm rounded-sm transition-all duration-200 hover:opacity-90 hover:scale-[1.01]"
        style={{
          backgroundColor: "oklch(0.22 0.065 255)",
          color: "oklch(0.975 0.008 85)",
          fontFamily: "'Noto Sans KR', sans-serif",
        }}
      >
        문의 보내기
      </button>
    </form>
  );
}
